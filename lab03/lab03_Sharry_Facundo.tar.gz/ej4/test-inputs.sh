for f in ../input/weather_cordoba.in; do ./weather.output $f > weather_cordoba.out ; done
