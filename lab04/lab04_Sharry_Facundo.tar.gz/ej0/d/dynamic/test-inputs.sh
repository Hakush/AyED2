for f in ../input/*; do ./program.output $f ; done
