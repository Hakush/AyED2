for f in input/*; do ./reverse $f ; done
