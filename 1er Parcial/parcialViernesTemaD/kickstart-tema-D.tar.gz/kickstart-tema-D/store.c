/*
  @file store.c
  @brief Implements store structure and methods
*/
#include <stdlib.h>
#include "store.h"

static const int NUMBER_OF_STORE_VARS = 4;

Store store_from_file(FILE* file, type_t type) {
  Store store;

  /*
    COMPLETAR
  */

  return store;
}
