#include <stdlib.h>
#include <stdbool.h>
#include <assert.h>
#include "set.h"

struct s_node {
    set_elem elem;
    struct s_node *next;
};

typedef struct s_node * node_t;

struct s_set {
    unsigned int size;
    node_t first;
};

static bool
invrep(set s) {
    // COMPLETAR
    return true;
}

static struct s_node *
create_node(set_elem e) {
    // COMPLETAR
}

static struct s_node *
destroy_node(struct s_node *node) {
    // COMPLETAR
}

/* CONSTRUCTORS */

set set_empty(void) {
    // COMPLETAR
}

set set_add(set s, set_elem e) {
    // COMPLETAR
}

/* OPERATIONS   */
unsigned int set_cardinal(set s) {
    // COMPLETAR
}

bool set_is_empty(set s) {
    // COMPLETAR
}

bool set_member(set_elem e, set s) {
    assert(invrep(s));
    node_t node=s->first;
    while (node!=NULL && node->elem < e) {
        node = node->next;
    }
    return node!=NULL && node->elem==e;
}


set set_elim(set s, set_elem e) {
    // COMPLETAR
}

set_elem set_get(set s) {
    assert(invrep(s) && !set_is_empty(s));
    return s->first->elem;
}

set_elem*
set_to_array(set s) {
    // COMPLETAR
}

set set_destroy(set s) {
    // COMPLETAR
}

